import type { Metadata } from "next";
import { Bricolage_Grotesque, Instrument_Sans } from "next/font/google";
import "./globals.css";

/** Titrage — grotesque contemporain, large et anguleux, façon affiche sérigraphiée */
const display = Bricolage_Grotesque({
  variable: "--font-display",
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  display: "swap",
});

/** Texte courant et données */
const sans = Instrument_Sans({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"
  ),
  title: {
    default: "BZ Family — Solidarité & Impact de Quartier",
    template: "%s | BZ Family",
  },
  description:
    "Association à but non lucratif — Ensemble, créons un impact positif dans notre quartier. Actions solidaires, événements, bénévolat et dons.",
  keywords: [
    "association",
    "solidarité",
    "bénévolat",
    "quartier",
    "BZ Family",
    "don",
    "événements",
  ],
  authors: [{ name: "BZ Family" }],
  openGraph: {
    type: "website",
    locale: "fr_FR",
    siteName: "BZ Family",
    title: "BZ Family — Solidarité & Impact de Quartier",
    description:
      "Ensemble, créons un impact positif dans notre quartier.",
  },
  twitter: {
    card: "summary_large_image",
    title: "BZ Family",
    description:
      "Association à but non lucratif — Solidarité, bénévolat et impact local.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="fr"
      className={`${display.variable} ${sans.variable} h-full`}
    >
      <body className="flex min-h-full flex-col bg-papier antialiased">
        {children}
      </body>
    </html>
  );
}
