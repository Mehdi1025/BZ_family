import { cn } from "@/lib/utils";

interface SectionHeadingProps {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className,
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "mb-12 lg:mb-16",
        align === "center" && "mx-auto max-w-3xl text-center",
        className
      )}
    >
      {eyebrow && (
        <div
          className={cn(
            "mb-6 flex items-center gap-3",
            align === "center" && "justify-center"
          )}
        >
          <span className="h-2 w-2 shrink-0 bg-rose" aria-hidden="true" />
          <span className="kicker opacity-70">{eyebrow}</span>
        </div>
      )}

      <h2 className="max-w-4xl text-balance font-display text-display-sm font-extrabold uppercase">
        {title}
      </h2>

      {description && (
        <p
          className={cn(
            "mt-5 max-w-xl text-pretty text-base leading-relaxed opacity-70 sm:text-lg",
            align === "center" && "mx-auto"
          )}
        >
          {description}
        </p>
      )}
    </div>
  );
}
