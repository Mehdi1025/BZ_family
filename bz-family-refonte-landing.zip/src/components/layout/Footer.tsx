import Link from "next/link";
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { siteConfig } from "@/lib/utils";

const footerLinks = {
  navigation: [
    { href: "/a-propos", label: "À propos" },
    { href: "/nos-actions", label: "Nos actions" },
    { href: "/evenements", label: "Événements" },
    { href: "/actualites", label: "Actualités" },
    { href: "/galerie", label: "Galerie" },
  ],
  engagement: [
    { href: "/devenir-benevole", label: "Devenir bénévole" },
    { href: "/faire-un-don", label: "Faire un don" },
    { href: "/partenaires", label: "Partenaires" },
    { href: "/contact", label: "Contact" },
  ],
  legal: [
    { href: "/mentions-legales", label: "Mentions légales" },
    { href: "/politique-confidentialite", label: "Confidentialité" },
  ],
};

const socials = [
  { href: siteConfig.social.facebook, label: "Facebook", Icon: Facebook },
  { href: siteConfig.social.instagram, label: "Instagram", Icon: Instagram },
  { href: siteConfig.social.linkedin, label: "LinkedIn", Icon: Linkedin },
];

export function Footer() {
  return (
    <footer className="bg-encre text-papier">
      {/* Signature typographique pleine largeur */}
      <div className="overflow-hidden border-b-2 border-papier/20">
        <p
          className="container-bz select-none py-6 font-display text-[clamp(3.5rem,15vw,13rem)] font-extrabold uppercase leading-[0.8] tracking-[-0.05em] text-papier/10"
          aria-hidden
        >
          BZ Family
        </p>
      </div>

      <div className="container-bz py-16 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-4">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center border-2 border-papier bg-outremer font-display text-lg font-extrabold leading-none">
                BZ
              </span>
              <span className="font-display text-xl font-extrabold uppercase tracking-tight">
                BZ Family
              </span>
            </div>
            <p className="mt-5 max-w-xs text-pretty text-sm leading-relaxed text-papier/70">
              Association loi 1901 dédiée à la solidarité de proximité et au lien
              social dans le quartier. Créée en 2019 par des habitants.
            </p>
            <div className="mt-6 flex gap-2.5">
              {socials.map(({ href, label, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-10 w-10 items-center justify-center border-2 border-papier/40 transition-colors hover:border-papier hover:bg-papier hover:text-encre"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2">
            <h3 className="kicker mb-5 text-papier/50">Le site</h3>
            <ul className="space-y-3">
              {footerLinks.navigation.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-papier/80 transition-colors hover:text-rose"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-2">
            <h3 className="kicker mb-5 text-papier/50">S&apos;engager</h3>
            <ul className="space-y-3">
              {footerLinks.engagement.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-papier/80 transition-colors hover:text-rose"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4">
            <h3 className="kicker mb-5 text-papier/50">Nous trouver</h3>
            <ul className="space-y-3 text-sm text-papier/80">
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-rose" />
                {siteConfig.address}
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 shrink-0 text-rose" />
                <a href={`tel:${siteConfig.phone.replace(/\s/g, "")}`} className="hover:text-rose">
                  {siteConfig.phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 shrink-0 text-rose" />
                <a href={`mailto:${siteConfig.email}`} className="hover:text-rose">
                  {siteConfig.email}
                </a>
              </li>
            </ul>

            <h3 className="kicker mb-3 mt-9 text-papier/50">La lettre du quartier</h3>
            <p className="mb-4 text-sm text-papier/70">
              Une fois par mois : les rendez-vous, les besoins, les coups de main.
            </p>
            <form className="flex gap-2">
              <label htmlFor="footer-email" className="sr-only">
                Votre adresse email
              </label>
              <Input
                id="footer-email"
                type="email"
                placeholder="vous@exemple.fr"
                className="border-papier/40 bg-transparent text-papier placeholder:text-papier/40 focus-visible:border-papier"
              />
              <Button variant="accent" type="submit">
                S&apos;inscrire
              </Button>
            </form>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t-2 border-papier/20 pt-7 sm:flex-row sm:items-center">
          <p className="text-xs text-papier/50">
            © {new Date().getFullYear()} BZ Family — Association loi 1901.
          </p>
          <div className="flex flex-wrap gap-6">
            {footerLinks.legal.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-xs text-papier/50 transition-colors hover:text-papier"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
