"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { navLinks } from "@/lib/data/mock";
import { cn } from "@/lib/utils";

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  return (
    <header className="sticky top-0 z-50 w-full border-b-2 border-encre bg-papier/95 backdrop-blur-sm">
      <div className="container-bz flex h-16 items-center justify-between gap-6 lg:h-[72px]">
        {/* Logotype — monogramme tamponné */}
        <Link href="/" className="group flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center border-2 border-encre bg-outremer font-display text-lg font-extrabold leading-none text-papier transition-colors duration-300 group-hover:bg-rose group-hover:text-encre">
            BZ
          </span>
          <span className="flex flex-col leading-none">
            <span className="font-display text-xl font-extrabold uppercase tracking-tight">
              BZ Family
            </span>
            <span className="kicker mt-1 opacity-60">Association de quartier</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 xl:flex">
          {navLinks.map((link) => {
            const isActive =
              link.href === "/"
                ? pathname === "/"
                : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "border-b-2 px-3 py-1.5 text-sm font-medium transition-colors",
                  isActive
                    ? "border-rose"
                    : "border-transparent hover:border-encre"
                )}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Button variant="outline" size="sm" asChild>
            <Link href="/devenir-benevole">Bénévole</Link>
          </Button>
          <Button variant="accent" size="sm" asChild>
            <Link href="/faire-un-don">Faire un don</Link>
          </Button>
        </div>

        <button
          type="button"
          className="flex h-10 w-10 items-center justify-center border-2 border-encre transition-colors hover:bg-encre hover:text-papier xl:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-expanded={mobileOpen}
          aria-label={mobileOpen ? "Fermer le menu" : "Ouvrir le menu"}
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Panneau mobile — affiche pleine page */}
      <div
        className={cn(
          "fixed inset-x-0 top-16 bottom-0 z-40 overflow-y-auto border-t-2 border-encre bg-papier transition-[opacity,transform] duration-300 ease-press xl:hidden",
          mobileOpen
            ? "translate-y-0 opacity-100"
            : "pointer-events-none -translate-y-3 opacity-0"
        )}
      >
        <nav className="container-bz flex flex-col py-4">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="border-b-2 border-encre py-4 font-display text-2xl font-bold uppercase tracking-tight transition-colors hover:text-outremer"
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <div className="mt-8 flex flex-col gap-3 pb-10">
            <Button variant="accent" size="lg" asChild>
              <Link href="/faire-un-don">Faire un don</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/devenir-benevole">Devenir bénévole</Link>
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
