"use client";

import { useEffect, useRef, useState } from "react";
import { useInView, useReducedMotion } from "framer-motion";
import { stats } from "@/lib/data/mock";

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });
  const reduced = useReducedMotion();

  useEffect(() => {
    if (!isInView) return;
    if (reduced) {
      setCount(value);
      return;
    }

    const duration = 1600;
    const start = performance.now();
    let frame = 0;

    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      // easeOutExpo
      const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
      setCount(Math.round(value * eased));
      if (p < 1) frame = requestAnimationFrame(tick);
    };

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [isInView, value, reduced]);

  return (
    <span ref={ref}>
      {count.toLocaleString("fr-FR")}
      {suffix}
    </span>
  );
}

/**
 * Le bilan — quatre chiffres posés comme un tableau d'affichage,
 * séparés par des filets d'encre plutôt que des cartes.
 */
export function Stats() {
  return (
    <section className="border-b-2 border-encre bg-papier">
      <div className="container-bz">
        <div className="grid divide-encre sm:grid-cols-2 sm:divide-x-2 lg:grid-cols-4">
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className={[
                "group py-10 lg:py-14",
                i !== 0 ? "border-t-2 border-encre sm:border-t-0" : "",
                i === 2 ? "lg:border-t-0 sm:border-t-2" : "",
                "sm:px-6 lg:px-8",
                i === 0 ? "sm:pl-0" : "",
              ].join(" ")}
            >
              <p className="font-display text-[clamp(3rem,7vw,5rem)] font-extrabold leading-[0.85] tracking-tight text-outremer transition-colors duration-300 group-hover:text-rose">
                <AnimatedCounter value={stat.value} suffix={stat.suffix} />
              </p>
              <p className="kicker mt-4 max-w-[14ch] opacity-70">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
