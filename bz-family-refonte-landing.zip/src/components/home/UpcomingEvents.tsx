import Link from "next/link";
import Image from "next/image";
import { ArrowRight, ArrowUpRight, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/shared/Reveal";
import { upcomingEvents } from "@/lib/data/mock";

const MONTHS = [
  "janv.", "févr.", "mars", "avril", "mai", "juin",
  "juil.", "août", "sept.", "oct.", "nov.", "déc.",
];

/**
 * Le programme.
 * Une ligne par rendez-vous, comme un tableau d'affichage : date en pavé,
 * jauge de places restantes, photo révélée au survol.
 */
export function UpcomingEvents() {
  return (
    <section className="ink-block border-b-2 border-encre">
      <div className="container-bz section-padding">
        <div className="mb-14 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-6 flex items-center gap-3">
              <span className="h-2 w-2 bg-jaune" aria-hidden />
              <span className="kicker text-papier/70">Le programme</span>
            </div>
            <h2 className="text-balance font-display text-display-sm font-extrabold uppercase text-papier">
              Prochains rendez-vous
            </h2>
          </div>
          <Button variant="inverse" asChild>
            <Link href="/evenements">
              Tout le calendrier
              <ArrowRight />
            </Link>
          </Button>
        </div>

        <ul className="border-t-2 border-papier/30">
          {upcomingEvents.map((event, i) => {
            const date = new Date(event.date);
            const spotsLeft = event.capacity - event.registeredCount;
            const fill = Math.round(
              (event.registeredCount / event.capacity) * 100
            );

            return (
              <Reveal as="li" key={event.id} delay={i * 0.08}>
                <Link
                  href={`/evenements/${event.slug}`}
                  className="group grid grid-cols-1 items-center gap-6 border-b-2 border-papier/30 py-7 text-papier transition-colors hover:bg-papier hover:text-encre md:grid-cols-12 md:gap-8 md:px-4"
                >
                  {/* Date */}
                  <div className="md:col-span-2">
                    <div className="inline-flex items-baseline gap-2 md:block">
                      <span className="font-display text-5xl font-extrabold leading-none tracking-tight">
                        {String(date.getDate()).padStart(2, "0")}
                      </span>
                      <span className="kicker md:mt-2 md:block">
                        {MONTHS[date.getMonth()]} {date.getFullYear()}
                      </span>
                    </div>
                  </div>

                  {/* Titre + lieu */}
                  <div className="md:col-span-5">
                    <h3 className="font-display text-2xl font-bold uppercase leading-[1] tracking-tight sm:text-[1.7rem]">
                      {event.title}
                    </h3>
                    <p className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm opacity-70">
                      <span className="flex items-center gap-1.5">
                        <MapPin className="h-3.5 w-3.5" />
                        {event.location}
                      </span>
                      <span>{event.time}</span>
                    </p>
                  </div>

                  {/* Visuel révélé */}
                  <div className="hidden md:col-span-2 md:block">
                    <div className="duotone relative aspect-[4/3] w-full overflow-hidden border-2 border-current opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                      <Image
                        src={event.imageUrl}
                        alt=""
                        fill
                        sizes="180px"
                        className="object-cover"
                      />
                    </div>
                  </div>

                  {/* Jauge */}
                  <div className="md:col-span-3">
                    <div className="flex items-center justify-between gap-4">
                      <div className="w-full max-w-[160px]">
                        <div className="h-2 w-full border-2 border-current">
                          <div
                            className="h-full bg-jaune"
                            style={{ width: `${fill}%` }}
                          />
                        </div>
                        <p className="kicker mt-2">
                          {spotsLeft > 0
                            ? `${spotsLeft} places restantes`
                            : "Complet"}
                        </p>
                      </div>
                      <ArrowUpRight className="h-6 w-6 shrink-0 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
                    </div>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
