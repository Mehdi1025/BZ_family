import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Overprint } from "@/components/shared/Overprint";

/** Ce qu'un don finance concrètement — trois paliers, trois effets. */
const tiers = [
  { amount: "10 €", effect: "Un panier repas pour une famille" },
  { amount: "25 €", effect: "Une semaine de soutien scolaire pour un enfant" },
  { amount: "60 €", effect: "Un atelier cuisine pour quinze personnes" },
];

export function VolunteerCTA() {
  return (
    <section className="border-b-2 border-encre bg-rose text-encre">
      <div className="container-bz section-padding">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7">
            <div className="mb-6 flex items-center gap-3">
              <span className="h-2 w-2 bg-encre" aria-hidden />
              <span className="kicker">Passer à l'action</span>
            </div>

            <h2 className="text-balance font-display text-display-md font-extrabold uppercase">
              Deux heures par mois{" "}
              <Overprint className="text-encre">suffisent.</Overprint>
            </h2>

            <p className="mt-8 max-w-lg text-pretty text-lg leading-relaxed">
              Distribuer des paniers le samedi, aider aux devoirs un soir par
              semaine, tenir un stand à la fête de rue. On vous forme, on vous
              accompagne, vous choisissez votre rythme.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-3">
              <Button size="lg" asChild>
                <Link href="/devenir-benevole">
                  Devenir bénévole
                  <ArrowRight />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/contact">Poser une question</Link>
              </Button>
            </div>
          </div>

          {/* Paliers de don */}
          <div className="lg:col-span-5">
            <div className="border-2 border-encre bg-papier">
              <div className="border-b-2 border-encre bg-encre px-6 py-4">
                <p className="font-display text-2xl font-extrabold uppercase leading-none text-papier">
                  Ou faire un don
                </p>
                <p className="kicker mt-2 text-papier/70">
                  Reçu fiscal — 66 % déductible
                </p>
              </div>

              <ul>
                {tiers.map((tier) => (
                  <li
                    key={tier.amount}
                    className="flex items-baseline gap-5 border-b-2 border-encre px-6 py-5"
                  >
                    <span className="w-16 shrink-0 font-display text-2xl font-extrabold leading-none text-outremer">
                      {tier.amount}
                    </span>
                    <span className="text-sm leading-snug">{tier.effect}</span>
                  </li>
                ))}
              </ul>

              <div className="p-6">
                <Button variant="accent" size="lg" className="w-full" asChild>
                  <Link href="/faire-un-don">
                    Faire un don
                    <ArrowRight />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
