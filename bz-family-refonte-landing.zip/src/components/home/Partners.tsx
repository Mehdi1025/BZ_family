import { partners } from "@/lib/data/mock";

/** Les soutiens — une banderole discrète, sans logos inventés. */
export function Partners() {
  const loop = [...partners, ...partners, ...partners];

  return (
    <section className="overflow-hidden border-b-2 border-encre bg-papier-deep py-10">
      <div className="container-bz mb-7 flex items-center gap-3">
        <span className="h-2 w-2 bg-outremer" aria-hidden />
        <span className="kicker opacity-70">
          Soutenus par — institutions, associations, commerçants du quartier
        </span>
      </div>

      <div className="flex w-max animate-marquee animate-marquee--reverse items-center gap-6">
        {loop.map((partner, i) => (
          <span
            key={`${partner.id}-${i}`}
            className="shrink-0 border-2 border-encre px-6 py-3 font-display text-lg font-bold uppercase tracking-tight"
          >
            {partner.name}
          </span>
        ))}
      </div>
    </section>
  );
}
