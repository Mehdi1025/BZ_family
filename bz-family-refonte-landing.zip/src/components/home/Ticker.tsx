const words = [
  "Aide alimentaire",
  "Soutien scolaire",
  "Fête de quartier",
  "Ateliers cuisine",
  "Sorties famille",
  "Accès aux droits",
];

/** Bandeau défilant — la banderole tendue au-dessus de la rue. */
export function Ticker() {
  const loop = [...words, ...words, ...words, ...words];

  return (
    <div className="ink-block overflow-hidden border-b-2 border-encre py-3.5">
      <div className="flex w-max animate-marquee items-center gap-8 whitespace-nowrap">
        {loop.map((word, i) => (
          <span key={`${word}-${i}`} className="flex items-center gap-8">
            <span className="font-display text-lg font-bold uppercase tracking-tight text-papier sm:text-xl">
              {word}
            </span>
            <span className="text-jaune" aria-hidden>
              ✳
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}
