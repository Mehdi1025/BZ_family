"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { actionPillars } from "@/lib/data/mock";

const EASE = [0.2, 0.8, 0.2, 1] as const;

/**
 * Les trois piliers.
 * Liste éditoriale : la photo de l'action survolée vient se caler dans la
 * colonne de droite. Sur mobile, chaque ligne porte sa propre image.
 */
export function Actions() {
  const [active, setActive] = useState(0);
  const reduced = useReducedMotion();

  return (
    <section className="border-b-2 border-encre bg-papier">
      <div className="container-bz section-padding">
        <div className="mb-14 flex flex-col gap-6 lg:mb-20 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-6 flex items-center gap-3">
              <span className="h-2 w-2 bg-rose" aria-hidden />
              <span className="kicker opacity-70">Ce qu'on fait</span>
            </div>
            <h2 className="max-w-3xl text-balance font-display text-display-sm font-extrabold uppercase">
              Trois piliers, zéro paperasse
            </h2>
          </div>
          <p className="max-w-sm text-pretty leading-relaxed opacity-70">
            Pas de dossier à monter, pas de rendez-vous à décrocher. On ouvre la
            porte, on écoute, on agit.
          </p>
        </div>

        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Liste */}
          <ul className="lg:col-span-7">
            {actionPillars.map((pillar, i) => (
              <li key={pillar.id}>
                <Link
                  href={`/nos-actions/${pillar.slug}`}
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  className="group block border-t-2 border-encre py-8 transition-colors last:border-b-2 hover:bg-encre hover:text-papier lg:py-10"
                >
                  <div className="flex items-start gap-5 px-1 lg:px-4">
                    <span className="kicker mt-2 shrink-0 opacity-50">
                      {pillar.label}
                    </span>

                    <div className="min-w-0 flex-1">
                      <h3 className="flex items-start justify-between gap-4 font-display text-3xl font-bold uppercase leading-[0.95] tracking-tight sm:text-4xl">
                        {pillar.title}
                        <ArrowUpRight className="mt-1 h-6 w-6 shrink-0 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
                      </h3>

                      <p className="mt-4 max-w-md text-pretty leading-relaxed opacity-70 transition-opacity group-hover:opacity-90">
                        {pillar.description}
                      </p>

                      <p className="mt-4 inline-block border-b-2 border-rose pb-0.5 text-sm font-semibold">
                        {pillar.metric}
                      </p>

                      {/* Image inline sur petits écrans */}
                      <div className="duotone relative mt-6 aspect-[16/9] w-full border-2 border-encre lg:hidden">
                        <Image
                          src={pillar.image}
                          alt={pillar.title}
                          fill
                          sizes="100vw"
                          className="object-cover"
                        />
                      </div>
                    </div>
                  </div>
                </Link>
              </li>
            ))}
          </ul>

          {/* Vitrine — desktop */}
          <div className="hidden lg:col-span-5 lg:block">
            <div className="sticky top-28">
              <div className="duotone relative aspect-[4/5] w-full border-2 border-encre">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={active}
                    initial={reduced ? false : { opacity: 0, scale: 1.04 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.45, ease: EASE }}
                    className="absolute inset-0"
                  >
                    <Image
                      src={actionPillars[active].image}
                      alt={actionPillars[active].title}
                      fill
                      sizes="35vw"
                      className="object-cover"
                    />
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="mt-4 flex items-center justify-between border-2 border-encre bg-jaune px-4 py-2.5">
                <span className="kicker">
                  {actionPillars[active].label}
                </span>
                <span className="kicker">
                  0{active + 1} / 0{actionPillars.length}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
