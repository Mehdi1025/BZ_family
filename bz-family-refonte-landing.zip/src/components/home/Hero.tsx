"use client";

import Link from "next/link";
import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowDown, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Overprint } from "@/components/shared/Overprint";
import { siteImages } from "@/lib/data/images";

const EASE = [0.2, 0.8, 0.2, 1] as const;

const line = {
  hidden: { opacity: 0, y: "0.35em" },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: 0.08 * i, ease: EASE },
  }),
};

export function Hero() {
  const reduced = useReducedMotion();
  const anim = reduced ? {} : { initial: "hidden", animate: "show" };

  return (
    <section className="relative overflow-hidden border-b-2 border-encre bg-papier">
      {/* Bandeau d'identification — l'ours de l'affiche */}
      <div className="border-b-2 border-encre">
        <div className="container-bz flex items-center justify-between gap-4 py-2.5">
          <p className="kicker">Association loi 1901 · Depuis 2019</p>
          <p className="kicker hidden sm:block">
            <span className="text-outremer">Prochain rendez-vous</span> — Atelier
            cuisine, samedi 12 avril
          </p>
          <p className="kicker text-rose">Ouvert à tous</p>
        </div>
      </div>

      <div className="container-bz">
        <div className="grid gap-x-12 lg:grid-cols-12">
          {/* ————— Colonne titre ————— */}
          <div className="flex flex-col justify-center py-14 lg:col-span-7 lg:py-24 xl:py-28">
            <motion.h1
              {...anim}
              className="font-display text-display-lg font-extrabold uppercase"
            >
              <motion.span
                variants={line}
                custom={0}
                className="block overflow-hidden"
              >
                Ensemble,
              </motion.span>
              <motion.span
                variants={line}
                custom={1}
                className="block overflow-hidden"
              >
                on change
              </motion.span>
              <motion.span
                variants={line}
                custom={2}
                className="block overflow-hidden text-outremer"
              >
                le quartier
              </motion.span>
              <motion.span
                variants={line}
                custom={3}
                className="block overflow-hidden"
              >
                <Overprint>pour de vrai.</Overprint>
              </motion.span>
            </motion.h1>

            <motion.div
              initial={reduced ? false : { opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.45 }}
              className="mt-9 max-w-xl"
            >
              <p className="text-pretty text-lg leading-relaxed sm:text-xl">
                BZ Family réunit des habitants, des bénévoles et des partenaires
                autour de trois choses simples&nbsp;: nourrir, accompagner,
                rassembler.
              </p>

              <div className="mt-9 flex flex-wrap items-center gap-3">
                <Button variant="accent" size="lg" asChild>
                  <Link href="/faire-un-don">
                    Faire un don
                    <ArrowRight />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="/devenir-benevole">Devenir bénévole</Link>
                </Button>
                <Link
                  href="/nos-actions"
                  className="ml-1 text-sm font-semibold underline decoration-2 underline-offset-[6px] transition-colors hover:text-rose"
                >
                  Voir nos actions
                </Link>
              </div>

              <p className="mt-8 flex items-center gap-2 text-sm opacity-60">
                <ArrowDown className="h-4 w-4 animate-bounce" aria-hidden />
                Reçu fiscal — 66&nbsp;% de votre don déductible des impôts
              </p>
            </motion.div>
          </div>

          {/* ————— Colonne image ————— */}
          <motion.div
            initial={reduced ? false : { opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.25, ease: EASE }}
            className="relative hidden lg:col-span-5 lg:block"
          >
            <div className="relative h-full min-h-[520px] border-x-2 border-encre">
              <div className="duotone absolute inset-0">
                <Image
                  src={siteImages.hero}
                  alt="Bénévoles de BZ Family lors d'une distribution dans le quartier"
                  fill
                  priority
                  sizes="(max-width: 1024px) 0vw, 42vw"
                  className="object-cover"
                />
              </div>

              {/* Repère d'impression */}
              <span
                className="absolute left-4 top-4 h-6 w-6 rounded-full border-2 border-jaune"
                aria-hidden
              />

              {/* Cachet — le chiffre qui compte */}
              <div className="absolute -left-10 bottom-10 -rotate-3 border-2 border-encre bg-jaune px-6 py-4 shadow-stamp">
                <p className="font-display text-4xl font-extrabold leading-none">
                  850
                </p>
                <p className="kicker mt-1.5">Familles accompagnées</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
