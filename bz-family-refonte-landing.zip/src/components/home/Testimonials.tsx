"use client";

import { useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { testimonials } from "@/lib/data/mock";

const EASE = [0.2, 0.8, 0.2, 1] as const;

/**
 * La parole des gens.
 * Une seule citation à la fois, en très grand — on choisit la personne
 * par son portrait, pas par une puce anonyme.
 */
export function Testimonials() {
  const [current, setCurrent] = useState(0);
  const reduced = useReducedMotion();
  const active = testimonials[current];

  return (
    <section className="border-b-2 border-encre bg-papier">
      <div className="container-bz section-padding">
        <div className="mb-12 flex items-center gap-3">
          <span className="h-2 w-2 bg-outremer" aria-hidden />
          <span className="kicker opacity-70">On en parle</span>
        </div>

        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Sélecteur de portraits */}
          <div className="order-2 flex gap-4 lg:order-1 lg:col-span-3 lg:flex-col lg:gap-5">
            {testimonials.map((t, i) => {
              const isActive = i === current;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setCurrent(i)}
                  aria-pressed={isActive}
                  className="group flex items-center gap-4 text-left"
                >
                  <span
                    className={`duotone relative block h-14 w-14 shrink-0 overflow-hidden border-2 transition-all duration-300 lg:h-16 lg:w-16 ${
                      isActive
                        ? "border-encre grayscale-0"
                        : "border-encre/30 opacity-45 group-hover:opacity-100"
                    }`}
                  >
                    <Image
                      src={t.avatar}
                      alt=""
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                  </span>
                  <span className="hidden min-w-0 lg:block">
                    <span
                      className={`block truncate font-display text-lg font-bold uppercase leading-none tracking-tight transition-colors ${
                        isActive ? "text-encre" : "text-encre/40"
                      }`}
                    >
                      {t.name}
                    </span>
                    <span className="kicker mt-1.5 block truncate opacity-60">
                      {t.role}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          {/* Citation */}
          <div className="order-1 lg:order-2 lg:col-span-9">
            <span
              className="block font-display text-[7rem] font-extrabold leading-[0.5] text-rose"
              aria-hidden
            >
              “
            </span>

            <AnimatePresence mode="wait">
              <motion.blockquote
                key={active.id}
                initial={reduced ? false : { opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.4, ease: EASE }}
                className="mt-6"
              >
                <p className="text-balance font-display text-[clamp(1.6rem,3.6vw,3rem)] font-semibold leading-[1.08] tracking-tight">
                  {active.content}
                </p>
                <footer className="mt-8 flex items-center gap-3 lg:hidden">
                  <span className="font-display text-lg font-bold uppercase">
                    {active.name}
                  </span>
                  <span className="kicker opacity-60">{active.role}</span>
                </footer>
              </motion.blockquote>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
