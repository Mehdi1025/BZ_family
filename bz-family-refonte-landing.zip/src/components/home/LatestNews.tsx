import Link from "next/link";
import Image from "next/image";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/shared/Reveal";
import { latestNews } from "@/lib/data/mock";
import { formatDate } from "@/lib/utils";

/**
 * Le journal.
 * Une une en grand format, deux brèves en pile — hiérarchie de gazette
 * de quartier plutôt que trois cartes identiques.
 */
export function LatestNews() {
  const [lead, ...rest] = latestNews;

  return (
    <section className="border-b-2 border-encre bg-papier-deep">
      <div className="container-bz section-padding">
        <div className="mb-14 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-6 flex items-center gap-3">
              <span className="h-2 w-2 bg-rose" aria-hidden />
              <span className="kicker opacity-70">Le journal</span>
            </div>
            <h2 className="text-balance font-display text-display-sm font-extrabold uppercase">
              Ce qui s'est passé
            </h2>
          </div>
          <Button variant="outline" asChild>
            <Link href="/actualites">
              Toutes les actualités
              <ArrowRight />
            </Link>
          </Button>
        </div>

        <div className="grid gap-10 lg:grid-cols-12 lg:gap-12">
          {/* La une */}
          <Reveal className="lg:col-span-7">
            <Link
              href={`/actualites/${lead.slug}`}
              className="group block h-full"
            >
              <div className="duotone relative aspect-[16/10] w-full overflow-hidden border-2 border-encre">
                <Image
                  src={lead.imageUrl}
                  alt={lead.title}
                  fill
                  sizes="(max-width: 1024px) 100vw, 55vw"
                  className="object-cover transition-transform duration-700 ease-press group-hover:scale-[1.04]"
                />
              </div>

              <div className="mt-6 flex items-center gap-3">
                <Badge variant="accent">{lead.category}</Badge>
                <span className="kicker opacity-60">
                  {formatDate(lead.publishedAt)}
                </span>
              </div>

              <h3 className="mt-4 text-balance font-display text-3xl font-extrabold uppercase leading-[0.95] tracking-tight transition-colors group-hover:text-outremer sm:text-4xl">
                {lead.title}
              </h3>
              <p className="mt-4 max-w-xl text-pretty leading-relaxed opacity-70">
                {lead.excerpt}
              </p>
              <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold underline decoration-2 underline-offset-[6px]">
                Lire l'article
                <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
              </span>
            </Link>
          </Reveal>

          {/* Les brèves */}
          <div className="flex flex-col lg:col-span-5">
            {rest.map((article, i) => (
              <Reveal key={article.id} delay={0.1 + i * 0.1}>
                <Link
                  href={`/actualites/${article.slug}`}
                  className="group flex gap-5 border-t-2 border-encre py-7 transition-colors last:border-b-2 hover:text-outremer"
                >
                  <div className="duotone relative aspect-square w-24 shrink-0 overflow-hidden border-2 border-encre sm:w-32">
                    <Image
                      src={article.imageUrl}
                      alt={article.title}
                      fill
                      sizes="128px"
                      className="object-cover transition-transform duration-700 ease-press group-hover:scale-110"
                    />
                  </div>

                  <div className="min-w-0">
                    <span className="kicker opacity-60">
                      {formatDate(article.publishedAt)} · {article.category}
                    </span>
                    <h3 className="mt-2 text-balance font-display text-xl font-bold uppercase leading-[1.02] tracking-tight sm:text-2xl">
                      {article.title}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm leading-relaxed opacity-70">
                      {article.excerpt}
                    </p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
