import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/** Étiquettes façon tampon : capitales étroites, filet net, zéro arrondi. */
const badgeVariants = cva(
  "inline-flex items-center rounded-sm border-2 px-2.5 py-1 font-sans text-[0.65rem] font-bold uppercase tracking-[0.12em]",
  {
    variants: {
      variant: {
        default: "border-encre bg-encre text-papier",
        secondary: "border-encre bg-papier-deep text-encre",
        accent: "border-encre bg-rose text-encre",
        jaune: "border-encre bg-jaune text-encre",
        outline: "border-encre bg-transparent text-encre",
        inverse: "border-papier bg-transparent text-papier",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}

export { Badge, badgeVariants };
