import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Boutons "encre" — aplats pleins, filet noir 2px, ombre portée dure.
 * L'enfoncement au clic reprend le geste du tampon.
 */
const buttonVariants = cva(
  [
    "group/btn relative inline-flex items-center justify-center gap-2 whitespace-nowrap",
    "rounded-sm border-2 border-encre font-sans font-semibold",
    "transition-all duration-200 ease-press",
    "focus-visible:outline-none focus-visible:ring-0",
    "disabled:pointer-events-none disabled:opacity-50",
    "[&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
    "[&_svg]:transition-transform [&_svg]:duration-200",
    "hover:[&_svg:last-child]:translate-x-1",
  ].join(" "),
  {
    variants: {
      variant: {
        default:
          "bg-encre text-papier shadow-[3px_3px_0_0_#2B2FD3] hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-[5px_5px_0_0_#2B2FD3] active:translate-x-0 active:translate-y-0 active:shadow-[0_0_0_0_#2B2FD3]",
        accent:
          "bg-rose text-encre shadow-[3px_3px_0_0_#0E0E12] hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-[5px_5px_0_0_#0E0E12] active:translate-x-0 active:translate-y-0 active:shadow-[0_0_0_0_#0E0E12]",
        accentWarm:
          "bg-jaune text-encre shadow-[3px_3px_0_0_#0E0E12] hover:-translate-x-[2px] hover:-translate-y-[2px] hover:shadow-[5px_5px_0_0_#0E0E12] active:translate-x-0 active:translate-y-0 active:shadow-[0_0_0_0_#0E0E12]",
        outline:
          "border-encre bg-transparent text-encre hover:bg-encre hover:text-papier",
        /** Sur aplat outremer */
        inverse:
          "border-papier bg-transparent text-papier hover:bg-papier hover:text-encre",
        secondary:
          "bg-papier-deep text-encre hover:bg-encre hover:text-papier",
        ghost:
          "border-transparent px-0 text-encre underline decoration-2 underline-offset-[6px] hover:decoration-rose hover:text-rose",
        link: "border-transparent px-0 text-outremer underline underline-offset-4 hover:text-rose",
      },
      size: {
        default: "h-11 px-5 text-[0.9rem]",
        sm: "h-9 px-4 text-xs uppercase tracking-wider",
        lg: "h-14 px-7 text-base",
        icon: "h-11 w-11 px-0",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
