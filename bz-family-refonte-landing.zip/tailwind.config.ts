import type { Config } from "tailwindcss";

/**
 * BZ Family — Design system "Affiche de quartier"
 * Direction : sérigraphie / risographie. Encres pleines, surimpression décalée,
 * papier grainé. Tout est dérivé de 5 encres.
 */
const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        /* ————— Encres ————— */
        encre: "#0E0E12",
        outremer: {
          DEFAULT: "#2B2FD3",
          deep: "#1B1E92",
          soft: "#DCDDF8",
        },
        rose: {
          DEFAULT: "#FF4D9D",
          deep: "#B4126A",
          soft: "#FFE0EE",
        },
        jaune: "#FFD400",
        papier: {
          DEFAULT: "#F0EFE9",
          deep: "#E4E2D8",
        },

        /* ————— Alias sémantiques (compat pages existantes) ————— */
        primary: {
          DEFAULT: "#2B2FD3",
          50: "#EFF0FC",
          100: "#DCDDF8",
          200: "#BCBEF1",
          300: "#9497E9",
          400: "#6266DE",
          500: "#2B2FD3",
          600: "#2427B3",
          700: "#1B1E92",
          800: "#151770",
          900: "#0F114F",
        },
        accent: {
          DEFAULT: "#FF4D9D",
          warm: "#B4126A",
          50: "#FFF1F7",
          100: "#FFE0EE",
          200: "#FFC0DC",
          300: "#FF95C3",
          400: "#FF4D9D",
          500: "#F02782",
          600: "#D1136B",
          700: "#B4126A",
        },
        surface: {
          DEFAULT: "#F0EFE9",
          muted: "#E4E2D8",
        },
        foreground: {
          DEFAULT: "#0E0E12",
          muted: "#5C5B55",
        },
        border: "#0E0E12",
        input: "#0E0E12",
        ring: "#2B2FD3",
        background: "#F0EFE9",
        destructive: "#D1136B",
        "destructive-foreground": "#FFFFFF",
        muted: {
          DEFAULT: "#E4E2D8",
          foreground: "#5C5B55",
        },
        card: {
          DEFAULT: "#F0EFE9",
          foreground: "#0E0E12",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "Impact", "sans-serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      fontSize: {
        "display-sm": ["clamp(2.5rem,6vw,3.75rem)", { lineHeight: "0.92", letterSpacing: "-0.03em" }],
        "display-md": ["clamp(3rem,8.5vw,6rem)", { lineHeight: "0.88", letterSpacing: "-0.035em" }],
        "display-lg": ["clamp(3.5rem,11vw,9rem)", { lineHeight: "0.85", letterSpacing: "-0.04em" }],
      },
      borderRadius: {
        none: "0",
        sm: "2px",
        md: "2px",
        lg: "3px",
        xl: "3px",
        "2xl": "4px",
      },
      borderWidth: {
        3: "3px",
      },
      boxShadow: {
        soft: "0 1px 0 0 #0E0E12",
        card: "6px 6px 0 0 #0E0E12",
        "card-rose": "6px 6px 0 0 #FF4D9D",
        stamp: "4px 4px 0 0 #0E0E12",
      },
      transitionTimingFunction: {
        press: "cubic-bezier(0.2, 0.8, 0.2, 1)",
      },
    },
  },
  plugins: [],
};

export default config;
